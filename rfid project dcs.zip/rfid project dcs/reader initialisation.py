import RPi.GPIO as GPIO
import csv
from mfrc522 import SimpleMFRC522
from twilio.rest import Client
reader = SimpleMFRC522()

try:
        id, text = reader.read()
        account_sid = 'AC8b1830519bf1ac4fe8076e822187caf9'
        auth_token = '49eb9cb93e98edbe6adf5727e2d5aefe'
        client = Client(account_sid, auth_token)
        message = client.messages.create(
        from_='+12056228026',
        body=f"Your courier with the sender name 'George' has crossed {text}. You can expect you order today.",
        to='+918688261052'
        )

        print(f"Order I'd {id}")
        print(f"{text} area courier location updated")
        print("Message successfully sent")
        with open('/home/itsvenu22/sri/del_status', 'a', newline='') as file:
                writer = csv.writer(file)
                writer.writerows(data)
finally:
        GPIO.cleanup()
